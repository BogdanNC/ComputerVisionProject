#pragma once

#include "ofMain.h"

class MyPoint
{
public:
	float x, y;
};